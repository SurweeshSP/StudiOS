# TODO: Fix Sidebar Routing Issue

- [x] Remove Routes and Route components from Sidebar.jsx
- [x] Add Sidebar component to App.jsx
- [x] Add routes for Sidebar pages (Landing, Attendance, Details, Analytics) in App.jsx
- [x] Test sidebar button routing functionality

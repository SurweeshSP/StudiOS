
function Analytics() {
    return (
        <div className="">
            <h1 className="mt-20">This is Analytics page</h1>
        </div>
    )
}

export default Analytics;